## Team: 6145
## Team Name: Recoders


### Problem Statement:
The education model moving towards pure ratafication and no innovation or interaction.


### Solution: 
An educational platform to provide more interactive and innovative primary education. That makes student learn more better and more effectively.


### Presentation Link:
https://drive.google.com/file/d/1dIkK5Yoxgnhg58rEYH8AySnWsyaBZHHj/view?usp=drivesdk





### Team Member Details:
1. Abhay Singh (lead)
2. Alok pratap Verma
3. Vidhi Sharma
4. Diti Verma